// expmain.cpp
//
// ICS 46 Winter 2019
// Project #4: Rock and Roll Stops the Traffic
//
// Do whatever you'd like here.  This is intended to allow you to experiment
// with your code, outside of the context of the broader program or Google
// Test.
#include <string>
#include <iostream>

int main()
{
	std::string test = "5";

	std::cout << std::stoi(test) << std::endl;

    return 0;
}

