// expmain.cpp
//
// ICS 46 Winter 2019
// Project #1: Dark at the End of the Tunnel
//
// Do whatever you'd like here.  This is intended to allow you to experiment
// with the given classes in the darkmaze library, or with your own
// algorithm implementations, outside of the context of the GUI or
// Google Test.
#include <iostream>
#include <vector>

int main()
{
	std::vector<int> x;
	std::cout<< x.size() << std::endl;

    return 0;
}

